#import <Foundation/Foundation.h>


int
main() {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

    __main();

    [pool drain];
    return 0;
}

// @"%d",
