#import <Foundation/Foundation.h>

#define log NSLog


@interface Student:NSObject {
    NSString * name;
    int64_t height;
}
@end
func NewStudent(NSString * name, int64_t height) (*Student) {
    var r = &Student{}
    r.name = name
    r.height = height
    return r
}
void
__main() {
    *Student s = NewStudent(@"gua", 169);
    log(s.height);
}
